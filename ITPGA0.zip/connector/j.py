import mysql.connector
from datetime import date

# Connect to MySQL
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='6P@ssword6',
    database='Video_store'
)
cursor = conn.cursor()
def Video_store_menu():
 Welcome = ("Register Customer")
 print = (Welcome)
 Cellphone - int(input("Enter phone your number:"))

 if Cellphone is not_is.digit() and len(Cellphone) is not_ == 10:
                print("Invalid number,")
     else:
      Cellphone is not_in_Video_store
     Register_Customer = append(Name, Surname, Adresss)
     Name = input("Enter your name:")
                Surname = input("Enter your surname:")
                Address = input("Enter your address:")
            print("Successfully registerd!")

            print("Register Movie")
            Movie = input("Enter which movie you want to register:")
            type = ("R. Red box")
            type = ("B. Black box")
            if type == "R":
                print("You have selected Red box new movies")
            elif type == B:
                print("You have selected black box old movies")
                Register_Movie = append(Movie, Type)

            print("Hire Out Movie")
            Cellphone - int(input("Enter phone your number:"))
            VideoID = int(input("Enter Video ID:"))

            print("ReturnMovie")
            VideoID = int(input("Enter Video ID:"))

            conn.close()
